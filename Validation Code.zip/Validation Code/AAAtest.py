#compare two tensor file‘s structure
import numpy as np
from visualize import read_tensor

def compare_bsdf_fields(path_a, path_b):
    print(f"\n🔍 Comparing {path_a} vs {path_b}")
    ta = read_tensor(path_a)
    tb = read_tensor(path_b)

    fields_a = set(ta.keys())
    fields_b = set(tb.keys())

    all_fields = sorted(fields_a | fields_b)
    for field in all_fields:
        print(f"\n-- {field} --")
        if field not in ta:
            print("  ❌ Missing in A")
            continue
        if field not in tb:
            print("  ❌ Missing in B")
            continue

        a, b = ta[field], tb[field]
        if a.shape != b.shape:
            print(f"  ❗Shape mismatch: {a.shape} vs {b.shape}")
            continue

        if np.isnan(a).any() or np.isnan(b).any():
            print("  ⚠ Contains NaN")
        if np.isinf(a).any() or np.isinf(b).any():
            print("  ⚠ Contains Inf")

        diff = np.abs(a - b)
        max_diff = diff.max()
        mean_diff = diff.mean()
        if max_diff < 1e-6:
            print("  ✅ Almost identical (max diff < 1e-6)")
        else:
            print(f"  ⚠ max diff = {max_diff:.6f}, mean diff = {mean_diff:.6f}")

        if (a < 0).any():
            print("  ⚠ A contains negative values")
        if (b < 0).any():
            print("  ⚠ B contains negative values")

# 使用方法：
compare_bsdf_fields("rglspec.bsdf", "reconstructed_fixed.bsdf")