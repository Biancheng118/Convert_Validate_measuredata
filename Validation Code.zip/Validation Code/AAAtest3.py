#test original file write and load
from visualize import read_tensor, write_tensor

# 读入原始 .bsdf 文件
data = read_tensor("rglspec.bsdf")

# 不做任何改动，原样写出
write_tensor("copied.bsdf", **data)