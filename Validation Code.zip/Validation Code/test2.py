#other test of structure
from visualize import read_tensor
t = read_tensor("replaced_wavelengths.bsdf")
for k in t:
    print(k, t[k].shape if hasattr(t[k], 'shape') else type(t[k]))
