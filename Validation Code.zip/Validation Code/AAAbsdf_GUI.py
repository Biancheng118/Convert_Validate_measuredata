#test on replace part of value of a name
import numpy as np
from visualize import read_tensor, write_tensor

# 读取原始 .bsdf 文件
data = read_tensor("rglspec.bsdf")

# 打印旧 wavelengths
print("旧 wavelength 值（前10项）：", data["wavelengths"][:10])

# 构造新的 wavelength 值（你可以替换为你自己的数组）
# 示例：均匀分布在 400 到 700 nm 之间
new_wavelengths = np.linspace(620, 750, 195).astype(np.float32)

# 替换字段
data["wavelengths"] = new_wavelengths

# 写出新的 .bsdf 文件
write_tensor("replaced_wavelengths.bsdf", **data)

print("✅ 替换成功并写出为 replaced_wavelengths.bsdf")