#visualize data structure
from visualize import read_tensor

t = read_tensor("reconstructed.bsdf")
print("Field names in your .bsdf file:")
print(list(t.keys()))
