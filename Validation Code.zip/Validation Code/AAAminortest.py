#test to edit single value of rgl tensor file
from visualize import read_tensor, write_tensor

# 1. 读取原始 bsdf
data = read_tensor("rglspec.bsdf")

# 2. 打印原始 wavelengths 前几项
print("原始 wavelengths（前10项）:", data["wavelengths"][:10])

# 3. 改动：减半
data["wavelengths"] *= 0.5

# 4. 写出新文件
write_tensor("modified_wavelengths.bsdf", **data)

print("✅ 写出成功：modified_wavelengths.bsdf")