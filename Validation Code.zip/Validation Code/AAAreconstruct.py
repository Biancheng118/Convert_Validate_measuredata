#force to keep the rgl format and structure
import numpy as np
import os
from visualize import write_tensor

folder = 'csvtest'

# 指定的正确字段顺序 + shape
field_order = [
    ('version',     (2,)),
    ('description', (29,)),
    ('phi_i',       (1,)),
    ('theta_i',     (8,)),
    ('wavelengths', (195,)),
    ('sigma',       (2, 128)),
    ('ndf',         (2, 128)),
    ('vndf',        (1, 8, 128, 128)),
    ('luminance',   (1, 8, 32, 32)),
    ('spectra',     (1, 8, 195, 32, 32)),
    ('jacobian',    (1,)),
    ('valid',       (1024,))
]

tensor_data = {}

for name, shape in field_order:
    path = os.path.join(folder, f"{name}.csv")
    try:
        # 读取为扁平数组，一维安全起见
        flat = np.genfromtxt(path, delimiter=',', skip_header=1).flatten()
        reshaped = flat.reshape(shape)
        tensor_data[name] = reshaped.astype(np.float32)
        print(f"[✓] {name}: loaded {flat.shape} → reshaped to {shape}")
    except Exception as e:
        print(f"[✗] {name}: failed to reshape to {shape}: {e}")

# 写出最终 bsdf 文件
write_tensor("reconstructed_fixed.bsdf", **tensor_data)