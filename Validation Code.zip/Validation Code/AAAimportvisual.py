#write bsdf tensor file to csv readable file
from visualize import read_tensor
import pandas as pd

def bsdf_to_csv(bsdf_path, output_dir="csvtest3"):
    import os
    os.makedirs(output_dir, exist_ok=True)
    
    tensor_data = read_tensor(bsdf_path)
    
    for key, value in tensor_data.items():
        output_path = os.path.join(output_dir, f"{key}.csv")
        # 如果数据是一维的，直接写为一列；否则平铺为2D再写出
        df = pd.DataFrame(value.reshape(-1, value.shape[-1]) if value.ndim > 1 else value)
        df.to_csv(output_path, index=False)
        print(f"已写入字段 {key} 到 {output_path}")

# 示例调用（替换为你的路径）
bsdf_to_csv("rglspec.bsdf")