bl_info = {
    "name": "io_scene_pbrt",
    "author": "Stig Atle Steffensen",
    "description": "PBRT rendering integration and material export for Blender.",
    "blender": (4, 3, 0),
    "version": (1, 0, 0),
    "location": "Render > PBRT Render settings",
    "warning": "",
    "category": "Render"
}

import bpy
from . import auto_load

# Initialize dynamic module loading and class registration order
auto_load.init()

# Blender addon registration entry points
def register():
    auto_load.register()

def unregister():
    auto_load.unregister()
